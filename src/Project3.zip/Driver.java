import java.io.IOException;

public class Driver 
{

	public static void main(String[] args) throws IOException 
	{
		Menu menu = new Menu();
		menu.start();

	}

}
